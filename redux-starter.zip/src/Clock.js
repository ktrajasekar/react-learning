import { React } from "react";

const Clock = () => {
    return (<div>test</div>)
}

export default Clock;