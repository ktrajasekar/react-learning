// project import
import Logo from './Logo';

// ==============================|| MAIN LOGO ||============================== //

const LogoSection = () => <Logo />;

export default LogoSection;
