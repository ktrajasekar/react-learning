import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyDUVXcvp-geJcOnnN5PEEe-sV49i4IyOKw",
    authDomain: "fire-react-6ffce.firebaseapp.com",
    projectId: "fire-react-6ffce",
    storageBucket: "fire-react-6ffce.appspot.com",
    messagingSenderId: "444521142985",
    appId: "1:444521142985:web:af725af51010eda5c40b18"
}
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export default app;