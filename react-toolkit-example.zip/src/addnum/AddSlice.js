import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    value: 0
}

export const addSlice = createSlice({
    initialState,
    name: "Add",
    reducers: {
        increment: (state) => {
            state.value -= 1
            console.log(state)
        }
    }
})

export const { increment } = addSlice.actions

export default addSlice.reducer