import React from "react";
import { useSelector, useDispatch } from 'react-redux';
import { increment } from "./AddSlice";
export default function AddNum() {
    const count = useSelector((state) => state.add.value);
    const dispatch = useDispatch();
    return (<>
        {count}
        <button
            aria-label="Increment value"
            onClick={() => dispatch(increment())}
        >Increment</button>
    </>)
}