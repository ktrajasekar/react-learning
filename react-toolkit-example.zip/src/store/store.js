import { configureStore } from "@reduxjs/toolkit";
import addSliceReducer from '../addnum/AddSlice'


export const store = configureStore({
    reducer: {
        add: addSliceReducer
    }
})