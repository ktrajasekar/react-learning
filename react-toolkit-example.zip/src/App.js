import logo from './logo.svg';
import './App.css';
import AddNum from './addnum/AddNum'

function App() {
  return (
    <div className="App">
      <AddNum />
    </div>
  );
}

export default App;
